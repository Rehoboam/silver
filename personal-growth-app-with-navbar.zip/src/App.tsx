
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Goals from './pages/Goals';
import Habits from './pages/Habits';
import Profile from './pages/Profile';
import StatsChart from './pages/StatsChart';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/goals" element={<Goals />} />
        <Route path="/habits" element={<Habits />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/stats" element={<StatsChart />} />
      </Routes>
    </Router>
  );
}

export default App;
