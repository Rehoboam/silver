
import React, { useState } from 'react';

const Goals = () => {
  const [goals, setGoals] = useState<string[]>([]);
  const [input, setInput] = useState('');

  const addGoal = () => {
    if (input.trim()) {
      setGoals([...goals, input]);
      setInput('');
    }
  };

  return (
    <div className="p-6 max-w-md mx-auto space-y-4">
      <h2 className="text-2xl font-bold">המטרות שלך</h2>
      <div className="flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-1 border px-3 py-2 rounded"
          placeholder="הוסף מטרה"
        />
        <button onClick={addGoal} className="bg-blue-500 text-white px-4 py-2 rounded">הוסף</button>
      </div>
      <ul className="space-y-2">
        {goals.map((goal, index) => (
          <li key={index} className="bg-gray-100 p-2 rounded">{goal}</li>
        ))}
      </ul>
    </div>
  );
};

export default Goals;
