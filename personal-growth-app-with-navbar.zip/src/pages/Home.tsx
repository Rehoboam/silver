
import React from 'react';

const inspiration = [
  "הדרך הארוכה מתחילה בצעד אחד קטן",
  "כל יום הוא הזדמנות חדשה",
  "הצלחה היא תוצאה של התמדה יומיומית"
];

const Home = () => {
  const quote = inspiration[Math.floor(Math.random() * inspiration.length)];

  return (
    <div className="h-screen flex flex-col justify-center items-center bg-gradient-to-br from-blue-100 to-purple-100 text-center px-4">
      <h1 className="text-3xl font-bold mb-6">ברוך הבא לאפליקציית ההתפתחות האישית שלך</h1>
      <p className="text-xl italic text-gray-700">"{quote}"</p>
    </div>
  );
};

export default Home;
