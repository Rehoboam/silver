
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'ראשון', מטרות: 3, הרגלים: 2 },
  { name: 'שני', מטרות: 2, הרגלים: 3 },
  { name: 'שלישי', מטרות: 4, הרגלים: 1 },
  { name: 'רביעי', מטרות: 1, הרגלים: 2 },
  { name: 'חמישי', מטרות: 5, הרגלים: 4 },
  { name: 'שישי', מטרות: 2, הרגלים: 3 },
  { name: 'שבת', מטרות: 0, הרגלים: 1 },
];

const StatsChart = () => {
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-4 text-center">סטטיסטיקת מטרות והרגלים</h2>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="מטרות" fill="#8884d8" />
          <Bar dataKey="הרגלים" fill="#82ca9d" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default StatsChart;
