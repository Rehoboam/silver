
import React from 'react';

const Profile = () => {
  return (
    <div className="p-6 max-w-md mx-auto space-y-6 text-center">
      <img src="/placeholder.svg" alt="avatar" className="w-20 h-20 rounded-full mx-auto" />
      <h2 className="text-xl font-bold">שם המשתמש</h2>
      <p className="text-gray-600">user@email.com</p>
      <div className="bg-gray-100 p-4 rounded">
        <p className="text-sm text-gray-500">מטרות שהושלמו</p>
        <p className="text-2xl font-bold text-green-600">7</p>
      </div>
      <button className="bg-red-500 text-white px-4 py-2 rounded">התנתק</button>
    </div>
  );
};

export default Profile;
