
import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="bg-white shadow px-6 py-4 flex justify-between items-center">
      <h1 className="text-lg font-bold text-gray-800">התפתחות אישית</h1>
      <div className="flex gap-4 text-sm text-blue-600">
        <Link to="/">בית</Link>
        <Link to="/goals">מטרות</Link>
        <Link to="/habits">הרגלים</Link>
        <Link to="/profile">פרופיל</Link>
        <Link to="/stats">סטטיסטיקה</Link>
      </div>
    </nav>
  );
};

export default Navbar;
