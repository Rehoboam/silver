# Personal Growth App

אפליקציה לפיתוח אישי: התחברות עם Supabase, ניהול מטרות, הרגלים ופרופיל.

## הרצה מקומית

```bash
npm install
cp .env.example .env
npm run dev
```
